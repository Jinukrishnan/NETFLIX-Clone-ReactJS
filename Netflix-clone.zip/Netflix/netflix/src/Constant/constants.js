export const baseUrl='https://api.themoviedb.org/3'
export const API_KEY="5badbbabb6d7aeaab586ebdbf7053e3b" 
export const imageUrl= "https://image.tmdb.org/t/p/original"